﻿using AAD.ImmoWin.Business.Classes;
using AAD.ImmoWin.Business.Services;
using Odisee.Common.Commands;
using Odisee.Common.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AAD.ImmoWin.WpfApp.ViewModels
{
	public class KlantenLijstViewModel : BaseViewModel
	{
		#region Properties

		#region Command properties
		public RelayCommand KlantToevoegenCommand { get; set; }
		public RelayCommand KlantWijzigenCommand { get; set; }
		public RelayCommand KlantVerwijderenCommand { get; set; }

		#endregion

		#region Observable properties

		private Klanten _klanten;

		public Klanten Klanten
		{
			get { return _klanten; }
			set
			{
				SetProperty(ref _klanten, value);
			}
		}

		private Klant _geselecteerdeKlant;

		public Klant GeselecteerdeKlant
		{
			get { return _geselecteerdeKlant; }
			set
			{
				SetProperty(ref _geselecteerdeKlant, value);
			}
		}

		private KlantLijstStatus _status	;

		public KlantLijstStatus Status
		{
			get { return _status; }
			set
			{

				
				if(SetProperty(ref _status, value))
				{
					switch (Status)
					{
						case KlantLijstStatus.Tonen:
							IsEnabled = true;
							break;
						case KlantLijstStatus.Toevoegen:
							break;
						case KlantLijstStatus.Wijzigen:
							break;
						case KlantLijstStatus.Verwijderen:
							break;
						default:
							break;
					}
				}
			}
		}

		#endregion

		#endregion

		#region Constructors

		public KlantenLijstViewModel(Klanten klanten)
		{
			// Observable properties
			Title = "Lijst klanten";
			Klanten = klanten;
			Status = KlantLijstStatus.Tonen;

			// Commands
			KlantToevoegenCommand = new RelayCommand(KlantToevoegenCommandExecute, KlantToevoegenCommandCanExecute);
			KlantWijzigenCommand = new RelayCommand(KlantWijzigenCommandExecute, KlantWijzigenCommandCanExecute);
			KlantVerwijderenCommand = new RelayCommand(KlantVerwijderenCommandExecute, KlantVerwijderenCommandCanExecute);
		}

        #endregion

        #region Methods

        #region Command  methods
        private string Voornm;
        public string Voornaam
        {
            get { return Voornm; }
            set { SetProperty(ref Voornm, value); }
        }
        private string Familienm;
        public string Familienaam
        {
            get { return Familienm; }
            set { SetProperty(ref Familienm, value); }
        }

        private void KlantToevoegenCommandExecute()
        {
            Klant nieuweKlant = new Klant
            {
                Voornaam = Voornaam,
                Familienaam = Familienaam
            };
            Klanten.Add(nieuweKlant);
            KlantenRepository.ToevoegenKlant(nieuweKlant);
            Voornaam = string.Empty;
            Familienaam = string.Empty;
        }
        private Boolean KlantToevoegenCommandCanExecute()
		{
            return IsEnabled = true;
        }

        private void KlantWijzigenCommandExecute()
        {
            IsEnabled = false;
            Status = KlantLijstStatus.Wijzigen;
        }
        private Boolean KlantWijzigenCommandCanExecute()
		{
			return GeselecteerdeKlant != null;
		}

		private void KlantVerwijderenCommandExecute()
		{ 
			KlantenRepository.VerwijderKlant(GeselecteerdeKlant);
		}
		private Boolean KlantVerwijderenCommandCanExecute()
		{
			return GeselecteerdeKlant != null;
		}
		#endregion
		#endregion
	}
}

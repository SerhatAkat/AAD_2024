﻿
namespace AAD.ImmoWin.Business.Enumerations
{
    public enum Huistype
    {
        Rijhuis,
        Tweegevel,
        Vrijstaand
    }
}

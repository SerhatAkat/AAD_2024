﻿using AAD.ImmoWin.Business.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AAD.ImmoWin.Business.Interfaces
{
    public interface IKlantService
    {
        void VoegKlantToe(Klant nieuweKlant);
        List<Klant> HaalAlleKlantenOp();
        void UpdateKlant(Klant klant);
        void VerwijderKlant(int klantId);
    }

}

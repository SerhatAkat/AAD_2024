﻿using AAD.ImmoWin.Business.Classes;
using AAD.ImmoWin.Business.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AAD.ImmoWin.Business.Services
{
    public static class KlantenRepository
    {
        private static Klanten klanten;
        private static Woning woningen;
        private static Huis huizen;
        private static Appartement appartementen;
        public static ImmoDbContext context = new ImmoDbContext();
        static KlantenRepository()
        {
            DbInitializer connectionRepository = new DbInitializer();

            connectionRepository.SeedGegevens(context);

            List<Klant> seededKlanten = context.Klanten.ToList();
            klanten = new Klanten();

            foreach (var klant in seededKlanten)
            {
                klanten.Add(klant);
            }
            context.SaveChanges();
        }

        public static Klanten GetKlanten()
        {
            return klanten;
        }

        public static Woning GetWoningen()
        {
            return woningen;
        }
        public static Huis GetHuizen()
        {
            return huizen;
        }
        public static Appartement GetAppartementen()
        {
            return appartementen;
        }

        public static IKlant ToevoegenKlant(IKlant klant)
        {
            context.Klanten.Add(klant as Klant);
            context.SaveChanges();
            return klant;
        }

        public static IKlant WijzigKlant(IKlant klant)
        {
            context.Klanten.AddOrUpdate(klant as Klant);
            context.SaveChanges();
            return klant;
        }

        public static void VerwijderKlant(IKlant klant)
        {
            context.Klanten.Remove(klant as Klant);
            klanten.Remove(klant);
            context.SaveChanges();
        }
    }
}

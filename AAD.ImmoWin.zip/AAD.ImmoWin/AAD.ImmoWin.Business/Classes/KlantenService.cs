﻿using AAD.ImmoWin.Business.Classes;
using AAD.ImmoWin.Business.Interfaces;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;

public class KlantService : IKlantService
{
    public void VoegKlantToe(Klant nieuweKlant)
    {
        using (var context = new ImmoDbContext())
        {
            context.Klanten.Add(nieuweKlant);
            context.SaveChanges();
        }
    }

    public List<Klant> HaalAlleKlantenOp()
    {
        using (var context = new ImmoDbContext())
        {
            return context.Klanten.ToList();
        }
    }

    public void UpdateKlant(Klant klant)
    {
        using (var context = new ImmoDbContext())
        {
            context.Entry(klant).State = EntityState.Modified;
            context.SaveChanges();
        }
    }

    public void VerwijderKlant(int klantId)
    {
        using (var context = new ImmoDbContext())
        {
            Klant klant = context.Klanten.Find(klantId);
            if (klant != null)
            {
                context.Klanten.Remove(klant);
                context.SaveChanges();
            }
        }
    }
}

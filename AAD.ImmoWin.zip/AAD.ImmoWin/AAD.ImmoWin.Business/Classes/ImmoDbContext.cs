﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AAD.ImmoWin.Business.Classes
{
    public class ImmoDbContext : DbContext
    {
        public DbSet<Klant> Klanten { get; set; }
        public DbSet<Woning> Woningen { get; set; }
        public DbSet<Adres> Adresses { get; set; }
        public DbSet<Appartement> Appartementen { get; set; }
        public DbSet<Huis> Huizen { get; set; }


        public ImmoDbContext() : base("DataImmoWin")
        {
            Database.SetInitializer(new DropCreateDatabaseIfModelChanges<ImmoDbContext>());
        }
    }
}

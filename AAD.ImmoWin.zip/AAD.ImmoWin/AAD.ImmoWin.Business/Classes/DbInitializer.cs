﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AAD.ImmoWin.Business.Classes
{
    public class DbInitializer : DropCreateDatabaseIfModelChanges<ImmoDbContext>
    {
        protected override void Seed(ImmoDbContext context)
        {
            SeedGegevens(context);
        }


        public void SeedGegevens(ImmoDbContext context)
        {
            if (!context.Klanten.Any())
            {
                Klant klant1 = new Klant { Voornaam = "Anna", Familienaam = "Rousseau" };
                Huis huis = new Huis(Business.Enumerations.Huistype.Rijhuis, new Adres("Stormstraat", 1, 1000, "Brussel"), DateTime.Now, 50);
                klant1.Eigendommen.Add(huis);
                context.Huizen.Add(huis);
                context.Adresses.Add(new Adres("Ambachtslaan", 3, 1000, "Brussel"));

                Klant klant2 = new Klant { Voornaam = "Lucas", Familienaam = "Deplae" };
                Appartement appartement = new Appartement(0, new Adres("Stormstraat", 2, 1000, "Leuven"), DateTime.Now, 100);
                klant2.Eigendommen.Add(appartement);
                context.Appartementen.Add(appartement);
                context.Adresses.Add(new Adres("Vrijheidslaan", 10, 2000, "Antwerpen"));

                context.Klanten.Add(klant1);
                context.Klanten.Add(klant2);
            }

            context.SaveChanges();
        }
    }
}
